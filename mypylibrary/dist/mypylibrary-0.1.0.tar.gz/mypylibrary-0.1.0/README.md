# MyPyLibrary

A simple Python library for math and string operations.

## Installation

Install via pip:

```bash
pip install mypylibrary
